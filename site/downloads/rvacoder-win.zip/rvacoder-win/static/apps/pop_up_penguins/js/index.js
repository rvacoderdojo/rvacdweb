
$(document).ready( function() {

    //This code will run after your page loads

    $(".yeti").mousedown(function() {
        alert("Yaaaarrrr!");
    });

});