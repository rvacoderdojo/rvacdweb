
$(document).ready( function() {

    //This code will run after your page loads

});